# ALPHA SENTINEL X — Unified Security Platform v5.0.0 BLACKSHIELD

**Arabic / English reporting • Authorized Red Team assessment • Blue Team analytics • BLACKSHIELD defensive validation**

Self-hosted security assessment and operations platform. This release integrates the earlier v4 platform with BLACKSHIELD defensive validation modules. It is a tested engineering baseline, not a certified commercial pentest suite or production-readiness guarantee.

## Included modules

### Identity, scope and governance
- Admin bootstrap from environment variables; PBKDF2-HMAC-SHA256 password hashing.
- Server-side sessions stored as token hashes in SQLite; expiry and logout revocation.
- HttpOnly, SameSite=Strict session cookie; CSRF token on state-changing API calls.
- Login rate limiting, security headers, CSP, and audit event history.
- Asset inventory with owner, authorization reference, explicit approval and revocation.
- Active asset assessment endpoints require an approved asset.

### Authorized technical assessment
- HTTPS security-header baseline review and TLS certificate metadata review.
- Bounded TCP connect checks against up to 24 selected ports; no banner grabbing or payloads.
- Same-origin API metadata checks using up to 20 unauthenticated GET requests; redirects are not followed and response bodies are not collected.
- Public-IP targets by default. Private lab targets require explicit configuration and written authorization; loopback/link-local/multicast/unspecified addresses remain blocked.

### BLACKSHIELD defensive validation
- **Firewall Configuration Audit:** pattern-based review of supplied UFW, iptables, nftables and Windows Firewall text exports for permissive defaults, disabled profiles and potentially exposed administrative/database ports.
- **Periodic Beacon Analytics:** analyzes supplied flow CSV telemetry for repeated low-volume connections with regular intervals. This is a heuristic, not proof of C2.
- **Local Synthetic Canary Test:** creates a synthetic marker file, copies it between local `source` and `sink` lab folders, compares SHA-256 hashes and writes JSONL event records. No network transfer occurs and no user/customer data is used.
- **SIEM/EDR Detection Coverage:** compares stable test event IDs against a supplied CSV export and reports detected/missed IDs and coverage percentage.
- Lab directory is controlled by `BLACKSHIELD_LAB_DIR`; it must be an absolute local filesystem path, not a network share.

### Blue Team and threat analysis
- CSV access-log analytics for request spikes, source concentration and HTTP error patterns.
- Offline PCAP/PCAPNG analysis with a packet processing ceiling. No packets are transmitted.
- Local IOC store and matching, incident tracking, findings history, dashboard and audit log.
- Printable HTML report export suitable for browser Save as PDF, with Arabic/English labels.

## Requirements
- Python 3.11+.
- Install development dependencies: `pip install -r requirements-dev.txt` (or runtime only: `pip install -r requirements.txt`).

## Local installation

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
cp .env.example .env
```

Set in `.env`:
- `ADMIN_PASSWORD`: unique password, at least 14 characters.
- `SECRET_KEY`: random unique secret, at least 48 characters (64+ recommended).
- `COOKIE_SECURE=false` for local HTTP testing; set `true` behind HTTPS.
- `ALLOW_PRIVATE_TARGETS=false` by default. Only enable for a properly isolated, authorized private lab.
- `BLACKSHIELD_LAB_DIR`: absolute local directory for synthetic canary files and JSONL events. Ensure the service account has access and the directory is not shared over the network.

Generate a secret:

```bash
python -c "import secrets; print(secrets.token_urlsafe(64))"
```

Start:

```bash
python run.py
```

Open `http://127.0.0.1:8000`.

## Docker

```bash
cp .env.example .env
# Edit .env first, then:
docker compose up --build -d
```

The Compose deployment should remain bound to localhost behind a properly configured HTTPS reverse proxy. Mount a persistent, local volume for `BLACKSHIELD_LAB_DIR` if using the canary workflow.

## BLACKSHIELD workflow

1. Sign in and open **BLACKSHIELD**.
2. Upload a firewall text export for static configuration review.
3. Upload a flow CSV with `timestamp,src_ip,dst_ip` and optional `dst_port,bytes` to inspect periodic low-volume destinations.
4. Run the local canary test. The service creates and copies only synthetic content inside `BLACKSHIELD_LAB_DIR` and records hashes and event IDs.
5. Export SIEM/EDR events to CSV with an `event_id` or `test_id` column. Compare against `ASX-CANARY-CREATE,ASX-CANARY-COPY,ASX-CANARY-HASH` to measure exact-ID detection coverage. Your SIEM integration must map the test activity to these stable identifiers for meaningful results.

## API additions

- `POST /api/blackshield/firewall-audit` — multipart text configuration upload.
- `POST /api/blackshield/beacon-audit` — multipart flow CSV upload.
- `POST /api/blackshield/canary-test` — local synthetic file create/copy/hash test.
- `POST /api/blackshield/detection-coverage` — multipart SIEM/EDR CSV plus `expected_event_ids` form field.
- `GET /api/blackshield/capabilities` — BLACKSHIELD module inventory and limitations.

## Security boundaries and limitations

BLACKSHIELD does not bypass firewalls, hide malicious activity, disable or evade EDR, collect credentials, establish persistence, or transfer real sensitive data. It tests defensive posture using supplied configuration/telemetry and a local synthetic-file workflow. It does not claim to detect every firewall rule or every C2 pattern. Validate results with the vendor's effective-policy tooling, packet telemetry, endpoint sensors and an independent security review. Keep written authorization and a defined test window for every active asset assessment.

## Verification

From the project root:

```bash
PYTHONPATH=. pytest -q
python -m compileall -q app run.py
```

The automated suite covers core assessment invariants and BLACKSHIELD parsing, beacon heuristics, canary integrity and event-ID coverage. Passing tests are not a penetration test or a production-readiness certification.


## iPhone / Safari deployment
See `IPHONE_DEPLOYMENT_AR.md` for the PWA setup and iPhone-only cloud deployment steps.
