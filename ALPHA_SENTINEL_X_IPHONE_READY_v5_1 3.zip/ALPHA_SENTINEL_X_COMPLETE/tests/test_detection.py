from app.detection import analyze_rows

def test_log_analysis_basic():
    raw = (
        "timestamp,source_ip,method,path,status\n"
        "2026-11-04T10:00:00Z,192.0.2.10,GET,/health,200\n"
        "2026-11-04T10:00:01Z,198.51.100.2,GET,/login,401\n"
    ).encode()
    result = analyze_rows(raw)
    assert result["total"] == 2
    assert result["unique_sources"] == 2
