from app.expert_engine import _host, AssessmentError, DEFAULT_PORTS
import pytest

def test_host_accepts_https():
    assert _host("https://example.com/path")[0] == "example.com"

def test_host_rejects_http():
    with pytest.raises(AssessmentError):
        _host("http://example.com")

def test_ports_are_bounded():
    assert len(DEFAULT_PORTS) <= 24
