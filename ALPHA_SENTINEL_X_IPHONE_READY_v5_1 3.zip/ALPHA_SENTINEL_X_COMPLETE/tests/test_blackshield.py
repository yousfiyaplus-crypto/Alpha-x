import csv
import io
from datetime import datetime, timedelta, timezone

from app.blackshield import (
    BlackshieldError, audit_firewall_config, analyze_beacon_csv,
    run_local_canary_test, compare_detection_coverage,
)


def test_firewall_audit_flags_inbound_accept():
    result = audit_firewall_config(b"-P INPUT ACCEPT\n")
    assert any(x["title"] == "iptables inbound default ACCEPT" for x in result["findings"])


def test_firewall_audit_rejects_empty():
    try:
        audit_firewall_config(b"  ")
        assert False, "expected error"
    except BlackshieldError:
        pass


def test_beacon_analysis_detects_regular_low_volume_contacts():
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=["timestamp", "src_ip", "dst_ip", "dst_port", "bytes"])
    writer.writeheader()
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    for i in range(8):
        writer.writerow({"timestamp": (start + timedelta(seconds=60*i)).isoformat(),
                         "src_ip": "192.0.2.10", "dst_ip": "198.51.100.9",
                         "dst_port": 443, "bytes": 400})
    result = analyze_beacon_csv(output.getvalue().encode())
    assert result["beacon_candidates"]
    assert result["beacon_candidates"][0]["connections"] == 8


def test_canary_is_local_and_hashes_match(tmp_path, monkeypatch):
    monkeypatch.setenv("BLACKSHIELD_LAB_DIR", str(tmp_path / "lab"))
    result = run_local_canary_test()
    assert result["integrity_match"] is True
    assert result["source_sha256"] == result["sink_sha256"]
    assert (tmp_path / "lab" / "sink" / result["filename"]).exists()
    assert "ASX-CANARY-COPY" in result["event_ids"]


def test_detection_coverage_compares_exact_ids():
    raw = b"timestamp,event_id,host\n2026-01-01T00:00:00Z,ASX-CANARY-CREATE,lab\n"
    result = compare_detection_coverage(raw, ["ASX-CANARY-CREATE", "ASX-CANARY-COPY"])
    assert result["coverage_percent"] == 50.0
    assert result["missed_events"] == ["ASX-CANARY-COPY"]
