import os
import pytest
from app.expert_engine import _host, AssessmentError
from app.auth import hash_password, verify_password
from app.detection import valid_ip


def test_password_hash_roundtrip():
    stored = hash_password("A-long-unique-test-password-2026!")
    assert verify_password("A-long-unique-test-password-2026!", stored)
    assert not verify_password("wrong-password", stored)


def test_url_requires_https_and_default_port():
    assert _host("https://example.com")[0] == "example.com"
    with pytest.raises(AssessmentError):
        _host("http://example.com")
    with pytest.raises(AssessmentError):
        _host("https://example.com:444")


def test_ip_normalization():
    assert valid_ip("192.0.2.1") == "192.0.2.1"
    assert valid_ip("not-an-ip") is None


def test_asset_url_rejects_credentials_and_non_https():
    with pytest.raises(AssessmentError):
        _host("https://user:pass@example.com")
    with pytest.raises(AssessmentError):
        _host("https://example.com:9443")


def test_private_target_blocked_by_default(monkeypatch):
    import socket
    monkeypatch.delenv("ALLOW_PRIVATE_TARGETS", raising=False)
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [(None, None, None, None, ("10.0.0.7", 0))])
    from app.expert_engine import _resolve
    with pytest.raises(AssessmentError):
        _resolve("internal.example")


def test_loopback_blocked_even_when_private_targets_enabled(monkeypatch):
    import socket
    monkeypatch.setenv("ALLOW_PRIVATE_TARGETS", "true")
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [(None, None, None, None, ("127.0.0.1", 0))])
    from app.expert_engine import _resolve
    with pytest.raises(AssessmentError):
        _resolve("localhost")
