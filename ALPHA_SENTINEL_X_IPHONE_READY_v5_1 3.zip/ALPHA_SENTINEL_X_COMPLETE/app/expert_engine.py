"""ALPHA SENTINEL X Expert assessment engine.
Non-destructive checks only: bounded TCP handshakes, HTTPS metadata and TLS inspection.
No exploit payloads, credential attacks, stealth, persistence, or data extraction.
"""
from __future__ import annotations
import socket, ssl, time, ipaddress, os
from datetime import datetime, timezone
from urllib.parse import urlparse, urlunparse, quote
import http.client

USER_AGENT = "ALPHA-SENTINEL-X/4.0 (authorized-security-assessment)"
DEFAULT_PORTS = (21, 22, 25, 53, 80, 110, 143, 443, 445, 587, 993, 995, 1433, 3306, 3389, 5432, 5900, 6379, 8000, 8080, 8443, 9200, 27017)

class AssessmentError(ValueError):
    pass

def _host(url: str) -> tuple[str, str]:
    try:
        parsed = urlparse(url)
        hostname = parsed.hostname
        port = parsed.port
    except ValueError as exc:
        raise AssessmentError("Malformed asset URL") from exc
    if parsed.scheme != "https" or not hostname:
        raise AssessmentError("Only registered HTTPS assets are accepted")
    if parsed.username or parsed.password:
        raise AssessmentError("Credentials in asset URLs are not allowed")
    if port not in (None, 443):
        raise AssessmentError("Only HTTPS on port 443 is supported for web/API assessment")
    try:
        host = hostname.encode("idna").decode("ascii").lower()
        if any(ch in host for ch in "\r\n\t /\\"):
            raise ValueError("invalid host")
        if ":" not in host and (not host or len(host) > 253 or not all(
            label and len(label) <= 63 and not label.startswith("-") and not label.endswith("-")
            and all(c.isalnum() or c == "-" for c in label) for label in host.rstrip(".").split("."))):
            raise ValueError("invalid hostname")
    except Exception as exc:
        raise AssessmentError("Invalid asset hostname") from exc
    return host, parsed.netloc

def _resolve(host: str):
    try:
        rows = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise AssessmentError(f"DNS resolution failed: {exc}")
    ips = sorted({r[4][0] for r in rows})
    if not ips:
        raise AssessmentError("No IP addresses resolved")
    allow_private = os.getenv("ALLOW_PRIVATE_TARGETS", "false").lower() == "true"
    for value in ips:
        addr = ipaddress.ip_address(value)
        if not addr.is_global and not allow_private:
            raise AssessmentError("Target resolves to a non-public IP. Private targets require ALLOW_PRIVATE_TARGETS=true and explicit written authorization.")
        if addr.is_loopback or addr.is_link_local or addr.is_multicast or addr.is_unspecified:
            raise AssessmentError("Loopback, link-local, multicast, and unspecified targets are blocked")
    return ips

def tcp_exposure(host: str, ports=DEFAULT_PORTS, timeout=0.45):
    """Check a fixed, small set of TCP ports with a single handshake each."""
    if len(ports) > 24 or any(type(x) is not int or x < 1 or x > 65535 for x in ports):
        raise AssessmentError("Invalid port selection")
    ips = _resolve(host)
    results=[]
    pinned_ip = ips[0]
    for port in ports:
        state="filtered_or_closed"
        start=time.monotonic()
        try:
            with socket.create_connection((pinned_ip, port), timeout=timeout):
                state="open"
        except (OSError, TimeoutError):
            pass
        results.append({"port":port,"state":state,"latency_ms":round((time.monotonic()-start)*1000,2)})
    return {"host":host,"resolved_ips":ips,"ports":results,"method":"single TCP connect; no payload/banner grabbing"}

def tls_audit(host: str, timeout=4):
    ctx=ssl.create_default_context()
    pinned_ip = _resolve(host)[0]
    with socket.create_connection((pinned_ip,443),timeout=timeout) as raw:
        with ctx.wrap_socket(raw,server_hostname=host) as conn:
            cert=conn.getpeercert()
            cipher=conn.cipher()
            not_after=cert.get("notAfter")
            expires=datetime.strptime(not_after,"%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc) if not_after else None
            days=(expires-datetime.now(timezone.utc)).days if expires else None
            return {"protocol":conn.version(),"cipher":cipher[0] if cipher else None,
                    "certificate_subject":str(cert.get("subject",[])),"issuer":str(cert.get("issuer",[])),
                    "expires_at":expires.isoformat() if expires else None,"days_until_expiry":days}

def _https_metadata(host: str, path_query: str, timeout=(3, 6)):
    """Fetch only HTTP status and headers over a socket pinned to a validated DNS IP."""
    ip = _resolve(host)[0]
    connect_timeout, read_timeout = timeout
    raw = socket.create_connection((ip, 443), timeout=connect_timeout)
    try:
        raw.settimeout(read_timeout)
        context = ssl.create_default_context()
        with context.wrap_socket(raw, server_hostname=host) as tls:
            host_header = f"[{host}]" if ":" in host else host
            request = (f"GET {path_query} HTTP/1.1\r\n"
                       f"Host: {host_header}\r\n"
                       f"User-Agent: {USER_AGENT}\r\n"
                       "Accept: application/json,text/html,*/*;q=0.5\r\n"
                       "Connection: close\r\n\r\n")
            tls.sendall(request.encode("ascii", errors="strict"))
            response = http.client.HTTPResponse(tls)
            response.begin()
            status = response.status
            headers = {k.lower(): v for k, v in response.getheaders()}
            response.close()
            return status, headers
    finally:
        try:
            raw.close()
        except OSError:
            pass


def web_audit(url: str):
    host, _ = _host(url)
    # Pin the request to the exact registered hostname; redirects are deliberately disabled.
    parsed=urlparse(url)
    clean=urlunparse(("https",parsed.netloc,parsed.path or "/", "", parsed.query, ""))
    request_path = quote(parsed.path or "/", safe="/%:@!$&'()*+,;=-._~")
    if parsed.query:
        request_path += "?" + quote(parsed.query, safe="=&;%:@!$'()*+,/?-._~")
    started=time.monotonic()
    try:
        status, headers = _https_metadata(host, request_path, timeout=(3,6))
    except (OSError, ssl.SSLError, ValueError, http.client.HTTPException) as exc:
        raise AssessmentError(f"HTTPS request failed: {str(exc)[:180]}")
    findings=[]
    def add(sev,title,detail): findings.append({"severity":sev,"title":title,"detail":detail})
    if "strict-transport-security" not in headers: add("medium","HSTS header missing","HTTPS response did not include Strict-Transport-Security.")
    if "content-security-policy" not in headers: add("low","CSP header missing","Content-Security-Policy was not observed on the response.")
    if "x-content-type-options" not in headers: add("low","MIME sniffing protection missing","X-Content-Type-Options was not observed.")
    if "referrer-policy" not in headers: add("low","Referrer-Policy missing","No Referrer-Policy header was observed.")
    if "server" in headers: add("info","Server banner disclosed",f"Server header is present: {headers['server'][:120]}")
    if status in (401,403): add("info","Root resource access controlled",f"Root resource returned HTTP {status}.")
    return {"host":host,"url":clean,"http_status":status,"elapsed_ms":round((time.monotonic()-started)*1000,2),
            "headers_observed":sorted(headers.keys()),"findings":findings,
            "note":"One GET request; redirects and response-body collection disabled."}

def assess_asset(url: str):
    host,_=_host(url)
    web=web_audit(url)
    try: tls=tls_audit(host)
    except (OSError,ssl.SSLError,ValueError) as exc:
        tls={"error":str(exc)[:180]}
    if tls.get("days_until_expiry") is not None and tls["days_until_expiry"] < 21:
        web["findings"].append({"severity":"high" if tls["days_until_expiry"] < 0 else "medium",
            "title":"TLS certificate expiry risk","detail":f"Certificate expires in {tls['days_until_expiry']} days."})
    return {"web":web,"tls":tls}

def api_surface_audit(base_url: str, paths: list[str]):
    """Check user-supplied same-origin API paths using bounded unauthenticated GETs."""
    host, _ = _host(base_url)
    if not paths or len(paths) > 20:
        raise AssessmentError("Provide between 1 and 20 API paths")
    base = urlparse(base_url)
    results=[]
    for path in paths:
        if not isinstance(path, str) or not path.startswith("/") or path.startswith("//") or "\\" in path:
            raise AssessmentError("API paths must be relative same-origin paths beginning with /")
        parsed_path=urlparse(path)
        if parsed_path.scheme or parsed_path.netloc or ".." in parsed_path.path.split("/"):
            raise AssessmentError("External or traversal API paths are not allowed")
        target_path = quote(parsed_path.path or "/", safe="/%:@!$&'()*+,;=-._~")
        if parsed_path.query:
            target_path += "?" + quote(parsed_path.query, safe="=&;%:@!$'()*+,/?-._~")
        try:
            status, headers = _https_metadata(host, target_path, timeout=(3,5))
        except (OSError, ssl.SSLError, ValueError, http.client.HTTPException) as exc:
            results.append({"path":path,"error":str(exc)[:140]})
            continue
        findings=[]
        if headers.get("access-control-allow-origin")=="*":
            findings.append({"severity":"medium","title":"Wildcard CORS policy","detail":"API response allows any origin; verify whether this endpoint returns sensitive data."})
        if headers.get("access-control-allow-credentials"," ").lower()=="true" and headers.get("access-control-allow-origin")=="*":
            findings.append({"severity":"high","title":"Conflicting permissive CORS headers","detail":"Wildcard origin and credential allowance were both observed; validate browser behavior and server policy."})
        if status in (401,403):
            findings.append({"severity":"info","title":"Access control observed","detail":f"Endpoint returned HTTP {status} to an unauthenticated GET."})
        results.append({"path":path,"status":status,"content_type":headers.get("content-type"),
                        "headers_observed":sorted(headers.keys()),"findings":findings})
    return {"host":host,"checked":len(results),"results":results,
            "note":"Unauthenticated GET only; no response bodies, redirects, or state-changing methods."}
