"""Authentication primitives for ALPHA SENTINEL X. Sessions are persisted as token hashes."""
import os, time, hmac, hashlib, secrets, base64, sqlite3
from pathlib import Path
from fastapi import Request, HTTPException
from starlette.responses import Response

SECRET = os.getenv("SECRET_KEY", "")
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "false").lower() == "true"
DB_PATH = os.getenv("DATABASE_PATH", "alpha_sentinel_x.db")
ATTEMPTS = {}


def _connect():
    path = Path(DB_PATH)
    if not path.is_absolute():
        path = Path.cwd() / path
    conn = sqlite3.connect(str(path), timeout=15)
    conn.row_factory = sqlite3.Row
    return conn


def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 600_000)
    return base64.b64encode(salt + dk).decode()


def verify_password(password, stored):
    try:
        raw = base64.b64decode(stored.encode())
        salt, expected = raw[:16], raw[16:]
        # Verify current and legacy v3 hashes during upgrade.
        for rounds in (600_000, 310_000):
            actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, rounds)
            if hmac.compare_digest(actual, expected):
                return True
        return False
    except Exception:
        return False


def _sig(token):
    if not SECRET or len(SECRET) < 48:
        raise RuntimeError("SECRET_KEY must contain at least 48 characters")
    return hmac.new(SECRET.encode(), token.encode(), hashlib.sha256).hexdigest()


def create_session(username):
    token = secrets.token_urlsafe(36)
    csrf = secrets.token_urlsafe(24)
    with _connect() as c:
        c.execute("DELETE FROM sessions WHERE expires < ?", (time.time(),))
        c.execute("INSERT INTO sessions(token_hash,username,csrf,expires) VALUES(?,?,?,?)",
                  (_sig(token), username, csrf, time.time()+28800))
    return token, csrf


def get_session(request: Request):
    token = request.cookies.get("asx_session")
    if not token:
        return None
    with _connect() as c:
        row = c.execute("SELECT username,csrf,expires FROM sessions WHERE token_hash=?", (_sig(token),)).fetchone()
        if not row:
            return None
        if row["expires"] < time.time():
            c.execute("DELETE FROM sessions WHERE token_hash=?", (_sig(token),))
            return None
        return {"user": row["username"], "csrf": row["csrf"], "expires": row["expires"]}


def revoke_session(request: Request):
    token = request.cookies.get("asx_session")
    if token:
        with _connect() as c:
            c.execute("DELETE FROM sessions WHERE token_hash=?", (_sig(token),))


def require_auth(request: Request):
    item = get_session(request)
    if not item:
        raise HTTPException(401, "يلزم تسجيل الدخول")
    if request.method not in ("GET", "HEAD", "OPTIONS"):
        supplied = request.headers.get("x-csrf-token", "")
        if not hmac.compare_digest(supplied, item["csrf"]):
            raise HTTPException(403, "رمز CSRF غير صالح")
    return item


def rate_limit(ip):
    now = time.time()
    attempts = [t for t in ATTEMPTS.get(ip, []) if now-t < 300]
    if len(attempts) >= 8:
        raise HTTPException(429, "محاولات دخول كثيرة، حاول بعد خمس دقائق")
    attempts.append(now)
    ATTEMPTS[ip] = attempts


def set_cookie(response: Response, token):
    response.set_cookie("asx_session", token, httponly=True, secure=COOKIE_SECURE,
                        samesite="strict", max_age=28800, path="/")


def clear_cookie(response: Response):
    response.delete_cookie("asx_session", path="/")
