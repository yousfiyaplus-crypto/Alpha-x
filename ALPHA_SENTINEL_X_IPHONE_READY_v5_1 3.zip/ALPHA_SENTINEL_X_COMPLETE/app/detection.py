import csv, io, ipaddress
from collections import Counter, defaultdict
from datetime import datetime, timezone

def valid_ip(value):
    try:
        return str(ipaddress.ip_address(str(value).strip()))
    except Exception:
        return None

def analyze_rows(raw: bytes):
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise ValueError("ملف CSV يجب أن يكون UTF-8")
    reader = csv.DictReader(io.StringIO(text))
    required = {"timestamp","source_ip","method","path","status"}
    if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
        raise ValueError("الأعمدة المطلوبة: timestamp,source_ip,method,path,status")
    rows=[]
    for row in reader:
        ip=valid_ip(row.get("source_ip"))
        try:
            ts=datetime.fromisoformat(row["timestamp"].replace("Z","+00:00"))
            status=int(row["status"])
            if ip: rows.append((ts,ip,row["method"],row["path"],status))
        except Exception:
            continue
    if not rows:
        raise ValueError("لم يتم العثور على سجلات صالحة")
    counts=Counter(x[1] for x in rows)
    minute=defaultdict(int)
    status=Counter()
    for ts,ip,method,path,code in rows:
        minute[ts.replace(second=0,microsecond=0)] += 1
        status[str((code//100)*100)] += 1
    avg=len(rows)/max(1,len(minute))
    peak=max(minute.values())
    findings=[]
    source_threshold=max(40,int(len(rows)*0.20))
    for ip,n in counts.most_common():
        if n>=source_threshold:
            findings.append({"severity":"medium","title":"تركيز مرتفع للطلبات من مصدر واحد",
                "detail":f"{ip} سجّل {n} طلباً من أصل {len(rows)}. تحقق من NAT والروبوتات وسياق التطبيق.",
                "indicator":ip})
    for ts,n in minute.items():
        if n>=max(80,avg*5):
            findings.append({"severity":"high","title":"ارتفاع حاد بمعدل الطلبات",
                "detail":f"{ts.isoformat()} — {n} طلب/دقيقة مقابل متوسط {avg:.1f}.",
                "indicator":""})
    err=sum(v for k,v in status.items() if k in ("400","500"))
    if err>=max(30,int(len(rows)*0.25)):
        findings.append({"severity":"medium","title":"ارتفاع استجابات الخطأ",
            "detail":f"{err} استجابة ضمن فئات 4xx/5xx من {len(rows)} سجل.","indicator":""})
    return {"total":len(rows),"unique_sources":len(counts),"peak_per_minute":peak,
            "average_per_minute":round(avg,2),"status_groups":dict(status),
            "top_sources":[{"ip":k,"requests":v} for k,v in counts.most_common(10)],
            "findings":findings}

def analyze_pcap(path):
    try:
        from scapy.utils import PcapReader
        from scapy.layers.inet import IP, TCP, UDP
        from scapy.layers.inet6 import IPv6
    except Exception:
        raise ValueError("مكتبة Scapy غير مثبتة")
    from collections import Counter, defaultdict
    import datetime
    total=0; sources=Counter(); per_second=defaultdict(int); protocols=Counter()
    try:
        with PcapReader(path) as reader:
            for pkt in reader:
                total += 1
                try:
                    ts=int(float(pkt.time))
                    per_second[ts]+=1
                    if IP in pkt:
                        sources[pkt[IP].src]+=1
                    elif IPv6 in pkt:
                        sources[pkt[IPv6].src]+=1
                    if TCP in pkt: protocols["TCP"]+=1
                    elif UDP in pkt: protocols["UDP"]+=1
                    else: protocols["Other"]+=1
                except Exception:
                    continue
                if total > 1_000_000:
                    raise ValueError("الملف يتجاوز حد مليون حزمة للتحليل في هذا الإصدار")
    except ValueError:
        raise
    except Exception as e:
        raise ValueError("تعذر قراءة PCAP: "+str(e)[:140])
    if not total: raise ValueError("ملف الالتقاط لا يحتوي حزم قابلة للتحليل")
    active=max(1,len(per_second))
    avg=total/active; peak=max(per_second.values())
    findings=[]
    for ip,n in sources.most_common(10):
        if n >= max(100,int(total*.25)):
            findings.append({"severity":"medium","title":"مصدر مهيمن في الالتقاط",
                "detail":f"{ip} يمثل {n} حزمة من أصل {total}. قد يكون NAT أو تدفقاً مشروعاً؛ تحقق يدوياً."})
    if peak>=max(200,avg*5):
        findings.append({"severity":"high","title":"ذروة كثافة حزم",
            "detail":f"الذروة {peak} حزمة/ثانية مقابل متوسط تقريبي {avg:.1f}."})
    return {"packets":total,"unique_sources":len(sources),"peak_packets_per_second":peak,
            "average_packets_per_second":round(avg,2),"protocols":dict(protocols),
            "top_sources":[{"ip":ip,"packets":n} for ip,n in sources.most_common(10)],
            "findings":findings}
