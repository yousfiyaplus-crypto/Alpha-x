"""BLACKSHIELD defensive assessment modules.

These modules perform real, bounded checks on supplied defensive artifacts and
a local synthetic-canary workflow. They do not implement covert access,
firewall bypass, credential theft, or external data exfiltration.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import os
import re
import shutil
import statistics
import tempfile
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class BlackshieldError(ValueError):
    pass


def audit_firewall_config(raw: bytes, filename: str = "firewall.txt") -> dict[str, Any]:
    """Static audit for common UFW/iptables/nftables/Windows export patterns."""
    if len(raw) > 2 * 1024 * 1024:
        raise BlackshieldError("Firewall configuration exceeds 2 MB")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise BlackshieldError("Firewall configuration must be UTF-8 text") from exc
    if not text.strip():
        raise BlackshieldError("Firewall configuration is empty")

    findings: list[dict[str, str]] = []

    def add(severity: str, title: str, detail: str, evidence: str = ""):
        findings.append({
            "severity": severity, "title": title, "detail": detail,
            "evidence": evidence[:240]
        })

    patterns = [
        (r"(?im)^\s*-\s*P\s+INPUT\s+ACCEPT\b",
         "high", "iptables inbound default ACCEPT",
         "The INPUT chain default policy appears to allow inbound traffic."),
        (r"(?im)^\s*-\s*P\s+FORWARD\s+ACCEPT\b",
         "high", "iptables forwarding default ACCEPT",
         "The FORWARD chain default policy appears to allow forwarded traffic."),
        (r"(?im)\bpolicy\s+accept\s*;",
         "high", "nftables chain policy ACCEPT",
         "A chain policy appears to accept traffic by default."),
        (r"(?im)\bDefault:\s*allow\s*\(incoming\)",
         "high", "UFW allows inbound by default",
         "UFW default inbound policy appears permissive."),
        (r"(?im)\bDefaultInboundAction\s*:\s*Allow\b",
         "high", "Windows Firewall inbound default Allow",
         "Windows Firewall export indicates an Allow inbound default."),
        (r"(?im)\bEnabled\s*:\s*False\b",
         "critical", "Windows Firewall profile disabled",
         "At least one exported firewall profile appears disabled."),
        (r"(?im)\b(0\.0\.0\.0/0|::/0|any|Any)\b.{0,100}\b(22|3389|445|1433|3306|5432|5900)\b",
         "high", "Potentially exposed administrative/database service",
         "A broad source range appears on a sensitive service rule."),
    ]
    for pattern, severity, title, detail in patterns:
        for match in re.finditer(pattern, text):
            line = text.count("\n", 0, match.start()) + 1
            evidence = text.splitlines()[line - 1].strip() if text.splitlines() else ""
            add(severity, title, f"{detail} Line {line}.", evidence)

    if not findings:
        add("info", "No known risky pattern matched",
            "No high-confidence permissive pattern was found by the built-in text rules. This is not proof that the firewall is correctly configured.")

    return {
        "filename": Path(filename).name[:120],
        "bytes_analyzed": len(raw),
        "findings": findings,
        "summary": {
            "critical": sum(x["severity"] == "critical" for x in findings),
            "high": sum(x["severity"] == "high" for x in findings),
            "medium": sum(x["severity"] == "medium" for x in findings),
            "info": sum(x["severity"] == "info" for x in findings),
        },
        "limitations": "Pattern-based review only. Validate rule order, interface binding, zones, NAT, cloud security groups and effective policy on the live firewall."
    }


def analyze_beacon_csv(raw: bytes) -> dict[str, Any]:
    """Find repeated low-volume destination contacts with low interval variance."""
    if len(raw) > 10 * 1024 * 1024:
        raise BlackshieldError("Traffic CSV exceeds 10 MB")
    try:
        decoded = raw.decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(decoded))
    except Exception as exc:
        raise BlackshieldError("Invalid CSV") from exc
    required = {"timestamp", "src_ip", "dst_ip"}
    if not reader.fieldnames or not required.issubset({x.strip().lower() for x in reader.fieldnames}):
        raise BlackshieldError("CSV requires timestamp, src_ip, dst_ip columns; dst_port and bytes are optional")

    # Normalize case and retain only bounded, parseable rows.
    rows = []
    for idx, original in enumerate(reader):
        if idx >= 100000:
            raise BlackshieldError("CSV exceeds 100,000 rows")
        row = {(k or "").strip().lower(): (v or "").strip() for k, v in original.items()}
        stamp = row.get("timestamp", "")
        try:
            dt = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            dt = dt.astimezone(timezone.utc)
        except Exception:
            continue
        dst = row.get("dst_ip") or row.get("domain") or "unknown"
        port = row.get("dst_port", "")
        key = (dst, port)
        try:
            byte_count = max(0, int(row.get("bytes") or 0))
        except ValueError:
            byte_count = 0
        rows.append((key, dt.timestamp(), byte_count, row.get("src_ip", "")))

    if not rows:
        raise BlackshieldError("No rows with valid ISO-8601 timestamps were found")

    groups: dict[tuple[str, str], list[tuple[float, int, str]]] = defaultdict(list)
    for key, ts, size, src in rows:
        groups[key].append((ts, size, src))

    candidates = []
    for (dst, port), events in groups.items():
        events.sort(key=lambda x: x[0])
        if len(events) < 6:
            continue
        intervals = [events[i][0] - events[i-1][0] for i in range(1, len(events))]
        mean_interval = statistics.mean(intervals)
        if mean_interval <= 0:
            continue
        cv = statistics.pstdev(intervals) / mean_interval if len(intervals) > 1 else 1.0
        mean_bytes = statistics.mean(x[1] for x in events)
        if cv <= 0.20 and mean_bytes <= 10000:
            candidates.append({
                "destination": dst, "port": port or None,
                "connections": len(events),
                "mean_interval_seconds": round(mean_interval, 2),
                "interval_cv": round(cv, 3),
                "mean_bytes": round(mean_bytes, 1),
                "confidence": "high" if cv <= 0.08 and len(events) >= 10 else "medium",
                "reason": "Repeated low-volume connections with regular timing; investigate as possible beaconing, not proof of C2."
            })

    candidates.sort(key=lambda x: (x["interval_cv"], -x["connections"]))
    return {
        "rows_analyzed": len(rows),
        "destination_groups": len(groups),
        "beacon_candidates": candidates[:100],
        "note": "Heuristic detection only. Legitimate health checks, agents and scheduled jobs can be periodic."
    }


def run_local_canary_test() -> dict[str, Any]:
    """Create and copy a synthetic canary file between two local lab directories."""
    base_raw = os.getenv("BLACKSHIELD_LAB_DIR", "").strip()
    if base_raw:
        base = Path(base_raw).expanduser()
        if not base.is_absolute():
            raise BlackshieldError("BLACKSHIELD_LAB_DIR must be an absolute local path")
    else:
        base = Path(tempfile.gettempdir()) / "alpha-sentinel-blackshield-lab"
    # Explicitly reject network-style paths. This workflow never transmits data.
    if str(base).startswith(("\\\\", "//")):
        raise BlackshieldError("Network paths are not accepted for the canary lab")
    base.mkdir(parents=True, exist_ok=True)
    source_dir = base / "source"
    sink_dir = base / "sink"
    source_dir.mkdir(exist_ok=True)
    sink_dir.mkdir(exist_ok=True)
    if source_dir.is_symlink() or sink_dir.is_symlink():
        raise BlackshieldError("Symlinked lab directories are not accepted")

    marker = "ASX-BLACKSHIELD-CANARY\nSynthetic security validation data. Contains no user or customer information.\n"
    token = hashlib.sha256(os.urandom(32)).hexdigest()[:20]
    filename = f"ASX_CANARY_{token}.txt"
    source = source_dir / filename
    sink = sink_dir / filename
    payload = marker.encode("utf-8")
    source.write_bytes(payload)
    source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    shutil.copy2(source, sink)
    sink_hash = hashlib.sha256(sink.read_bytes()).hexdigest()
    event_ids = ["ASX-CANARY-CREATE", "ASX-CANARY-COPY", "ASX-CANARY-HASH"]
    event = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "test_id": token,
        "event_ids": event_ids,
        "filename": filename,
        "source": str(source),
        "sink": str(sink),
        "bytes": len(payload),
        "source_sha256": source_hash,
        "sink_sha256": sink_hash,
        "integrity_match": source_hash == sink_hash,
        "note": "Synthetic file copied between local lab directories only; no network transfer occurred."
    }
    log_path = base / "blackshield-events.jsonl"
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False) + "\n")
    return event


def compare_detection_coverage(raw: bytes, expected_event_ids: list[str]) -> dict[str, Any]:
    """Compare expected lab event IDs against an exported SIEM/EDR CSV."""
    if len(raw) > 10 * 1024 * 1024:
        raise BlackshieldError("Detection export exceeds 10 MB")
    try:
        reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
    except UnicodeDecodeError as exc:
        raise BlackshieldError("Detection export must be UTF-8 CSV") from exc
    if not reader.fieldnames:
        raise BlackshieldError("Detection export is empty")
    fields = {x.strip().lower() for x in reader.fieldnames}
    if not ({"event_id", "test_id"} & fields):
        raise BlackshieldError("CSV must contain event_id or test_id column")
    seen = set()
    row_count = 0
    for row in reader:
        row_count += 1
        if row_count > 100000:
            raise BlackshieldError("Detection export exceeds 100,000 rows")
        normalized = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
        for key in ("event_id", "test_id"):
            if normalized.get(key):
                seen.add(normalized[key])
    expected = list(dict.fromkeys(x.strip() for x in expected_event_ids if x.strip()))
    if not expected or len(expected) > 100:
        raise BlackshieldError("Provide between 1 and 100 expected event IDs")
    detected = [x for x in expected if x in seen]
    missed = [x for x in expected if x not in seen]
    return {
        "rows_analyzed": row_count,
        "expected_events": len(expected),
        "detected_events": len(detected),
        "missed_events": missed,
        "detected": detected,
        "coverage_percent": round(100 * len(detected) / len(expected), 1),
        "note": "Coverage compares exact event identifiers. Map your SIEM/EDR export fields to stable test IDs before interpreting misses."
    }
