import os, sqlite3
from pathlib import Path
from contextlib import contextmanager

DB_PATH = os.getenv("DATABASE_PATH", "alpha_sentinel_x.db")

@contextmanager
def db():
    db_file = Path(DB_PATH)
    if not db_file.is_absolute():
        db_file = Path.cwd() / db_file
    db_file.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_file), timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'admin',
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS assets(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, url TEXT NOT NULL UNIQUE,
          owner TEXT NOT NULL, authorization_ref TEXT NOT NULL,
          approved INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS findings(
          id INTEGER PRIMARY KEY, asset_id INTEGER, source TEXT NOT NULL,
          severity TEXT NOT NULL, title TEXT NOT NULL, detail TEXT NOT NULL,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE SET NULL
        );
        CREATE TABLE IF NOT EXISTS incidents(
          id INTEGER PRIMARY KEY, title TEXT NOT NULL, severity TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'open', description TEXT NOT NULL,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS iocs(
          id INTEGER PRIMARY KEY, indicator TEXT UNIQUE NOT NULL,
          kind TEXT NOT NULL, source TEXT NOT NULL, confidence INTEGER NOT NULL DEFAULT 50,
          note TEXT NOT NULL DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS audit(
          id INTEGER PRIMARY KEY, actor TEXT NOT NULL, action TEXT NOT NULL,
          detail TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS sessions(
          token_hash TEXT PRIMARY KEY, username TEXT NOT NULL, csrf TEXT NOT NULL,
          expires REAL NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        """)
