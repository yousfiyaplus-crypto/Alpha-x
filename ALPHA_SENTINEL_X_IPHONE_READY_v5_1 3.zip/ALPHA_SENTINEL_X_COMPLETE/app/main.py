import os, re, tempfile, ipaddress
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Form
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from .db import db, init_db
from .auth import (hash_password, verify_password, create_session, get_session,
                   require_auth, rate_limit, set_cookie, clear_cookie, revoke_session)
from .detection import analyze_rows, analyze_pcap, valid_ip
from .safecheck import check_https_baseline

BASE_DIR = Path(__file__).resolve().parent
app=FastAPI(title="ALPHA SENTINEL X",version="5.0.0",docs_url=None,redoc_url=None)
app.mount("/static",StaticFiles(directory=str(BASE_DIR / "static")),name="static")
MAX_UPLOAD=int(os.getenv("MAX_UPLOAD_MB","20"))*1024*1024

def audit(actor,action,detail):
    with db() as c:
        c.execute("INSERT INTO audit(actor,action,detail) VALUES(?,?,?)",
                  (actor,action,str(detail)[:1000]))

@app.on_event("startup")
def startup():
    if len(os.getenv("SECRET_KEY", "")) < 48 or os.getenv("SECRET_KEY", "").startswith("CHANGE_THIS"):
        raise RuntimeError("Set a unique SECRET_KEY of at least 48 characters in .env")
    init_db()
    with db() as c:
        if not c.execute("SELECT id FROM users LIMIT 1").fetchone():
            username=os.getenv("ADMIN_USERNAME","admin")
            password=os.getenv("ADMIN_PASSWORD","")
            if len(password)<14 or password.startswith("CHANGE_THIS"):
                raise RuntimeError("Set ADMIN_PASSWORD to a unique password of at least 14 characters in .env")
            c.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",
                      (username,hash_password(password),"admin"))

@app.middleware("http")
async def security_middleware(request,call_next):
    if request.url.path.startswith("/api/") and request.url.path!="/api/login":
        try: require_auth(request)
        except HTTPException as e: return JSONResponse({"detail":e.detail},status_code=e.status_code)
    response=await call_next(request)
    response.headers["X-Content-Type-Options"]="nosniff"
    response.headers["X-Frame-Options"]="DENY"
    response.headers["Referrer-Policy"]="no-referrer"
    response.headers["Permissions-Policy"]="camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"]="default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    return response

def actor(request):
    s=get_session(request)
    return s["user"] if s else "system"

@app.get("/",response_class=HTMLResponse)
def home():
    return (BASE_DIR / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/health")
def health(): return {"status":"ok","platform":"ALPHA SENTINEL X","version":"5.0.0"}

@app.get("/manifest.webmanifest")
def pwa_manifest():
    return FileResponse(BASE_DIR / "static" / "manifest.webmanifest", media_type="application/manifest+json")

@app.get("/sw.js")
def pwa_service_worker():
    return FileResponse(BASE_DIR / "static" / "sw.js", media_type="application/javascript", headers={"Service-Worker-Allowed": "/", "Cache-Control": "no-cache"})

@app.post("/api/login")
def login(request:Request,username:str=Form(...),password:str=Form(...)):
    ip=request.client.host if request.client else "unknown"
    rate_limit(ip)
    with db() as c:
        user=c.execute("SELECT * FROM users WHERE username=?",(username,)).fetchone()
    if not user or not verify_password(password,user["password_hash"]):
        raise HTTPException(401,"بيانات الدخول غير صحيحة")
    token,csrf=create_session(username)
    response=JSONResponse({"ok":True,"csrf":csrf,"username":username})
    set_cookie(response,token)
    audit(username,"login","تسجيل دخول ناجح")
    return response

@app.post("/api/logout")
def logout(request:Request):
    revoke_session(request)
    response=JSONResponse({"ok":True}); clear_cookie(response)
    audit(actor(request),"logout","تسجيل خروج")
    return response

@app.get("/api/me")
def me(request:Request):
    s=require_auth(request); return {"username":s["user"],"csrf":s["csrf"]}

@app.get("/api/overview")
def overview():
    with db() as c:
        def n(q): return c.execute(q).fetchone()[0]
        recent=[dict(x) for x in c.execute("SELECT * FROM findings ORDER BY id DESC LIMIT 8")]
        return {"assets":n("SELECT COUNT(*) FROM assets"),
                "approved":n("SELECT COUNT(*) FROM assets WHERE approved=1"),
                "findings":n("SELECT COUNT(*) FROM findings"),
                "incidents":n("SELECT COUNT(*) FROM incidents WHERE status!='closed'"),
                "iocs":n("SELECT COUNT(*) FROM iocs"),"recent":recent}

class Asset(BaseModel):
    name:str=Field(min_length=2,max_length=100)
    url:str=Field(min_length=8,max_length=500)
    owner:str=Field(min_length=2,max_length=120)
    authorization_ref:str=Field(min_length=3,max_length=160)

@app.get("/api/assets")
def assets():
    with db() as c: return [dict(x) for x in c.execute("SELECT * FROM assets ORDER BY id DESC")]

@app.post("/api/assets")
def add_asset(data:Asset,request:Request):
    from urllib.parse import urlparse
    try:
        p=urlparse(data.url)
        valid_url = (p.scheme == "https" and bool(p.hostname) and not p.username and not p.password
                     and p.port in (None, 443) and not any(ch in data.url for ch in "\r\n\t "))
    except ValueError:
        valid_url = False
    if not valid_url: raise HTTPException(400,"أدخل عنوان HTTPS صحيحاً على المنفذ 443 دون بيانات اعتماد")
    with db() as c:
        try:
            cur=c.execute("INSERT INTO assets(name,url,owner,authorization_ref) VALUES(?,?,?,?)",
                (data.name,data.url.rstrip("/"),data.owner,data.authorization_ref))
        except Exception: raise HTTPException(409,"الأصل موجود مسبقاً أو البيانات غير صالحة")
        asset_id=cur.lastrowid
    audit(actor(request),"asset_registered",f"{asset_id}: {data.url}")
    return {"ok":True,"id":asset_id}

@app.post("/api/assets/{asset_id}/approve")
def approve_asset(asset_id:int,request:Request):
    with db() as c:
        cur=c.execute("UPDATE assets SET approved=1 WHERE id=?",(asset_id,))
        if not cur.rowcount: raise HTTPException(404,"الأصل غير موجود")
    audit(actor(request),"scope_approved",asset_id)
    return {"ok":True}

@app.post("/api/assets/{asset_id}/revoke")
def revoke_asset(asset_id:int,request:Request):
    with db() as c:
        cur=c.execute("UPDATE assets SET approved=0 WHERE id=?",(asset_id,))
        if not cur.rowcount: raise HTTPException(404,"الأصل غير موجود")
    audit(actor(request),"scope_revoked",asset_id)
    return {"ok":True}

@app.post("/api/assets/{asset_id}/baseline")
def baseline(asset_id:int,request:Request):
    with db() as c: a=c.execute("SELECT * FROM assets WHERE id=?",(asset_id,)).fetchone()
    if not a: raise HTTPException(404,"الأصل غير موجود")
    if not a["approved"]: raise HTTPException(403,"اعتمد الأصل في النطاق أولاً")
    try: result=check_https_baseline(a["url"])
    except Exception as e: raise HTTPException(400,str(e)[:200])
    with db() as c:
        for f in result["findings"]:
            c.execute("INSERT INTO findings(asset_id,source,severity,title,detail) VALUES(?,?,?,?,?)",
                      (asset_id,"https_baseline",f["severity"],f["title"],f["detail"]))
    audit(actor(request),"https_baseline",a["url"])
    return result

@app.post("/api/analyze/csv")
async def analyze_csv(request:Request,file:UploadFile=File(...)):
    if not file.filename.lower().endswith(".csv"): raise HTTPException(400,"ارفع CSV فقط")
    raw=await file.read(MAX_UPLOAD+1)
    if len(raw)>MAX_UPLOAD: raise HTTPException(413,"حجم الملف يتجاوز الحد المسموح")
    try: result=analyze_rows(raw)
    except ValueError as e: raise HTTPException(400,str(e))
    with db() as c:
        for f in result["findings"]:
            c.execute("INSERT INTO findings(source,severity,title,detail) VALUES(?,?,?,?)",
                      ("csv_log",f["severity"],f["title"],f["detail"]))
    audit(actor(request),"csv_log_analysis",file.filename)
    result["ioc_matches"]=match_iocs([x["ip"] for x in result["top_sources"]])
    return result

@app.post("/api/analyze/pcap")
async def analyze_pcap_route(request:Request,file:UploadFile=File(...)):
    if not file.filename.lower().endswith((".pcap",".pcapng")): raise HTTPException(400,"ارفع PCAP أو PCAPNG")
    raw=await file.read(MAX_UPLOAD+1)
    if len(raw)>MAX_UPLOAD: raise HTTPException(413,"حجم الملف يتجاوز الحد المسموح")
    tmp=None
    try:
        with tempfile.NamedTemporaryFile(delete=False,suffix=".pcap") as f:
            f.write(raw); tmp=f.name
        result=analyze_pcap(tmp)
    except ValueError as e: raise HTTPException(400,str(e))
    finally:
        if tmp and os.path.exists(tmp): os.unlink(tmp)
    with db() as c:
        for f in result["findings"]:
            c.execute("INSERT INTO findings(source,severity,title,detail) VALUES(?,?,?,?)",
                      ("pcap_analysis",f["severity"],f["title"],f["detail"]))
    result["ioc_matches"]=match_iocs([x["ip"] for x in result["top_sources"]])
    audit(actor(request),"pcap_analysis",file.filename)
    return result

def match_iocs(observed):
    if not observed: return []
    with db() as c:
        all_iocs=[dict(x) for x in c.execute("SELECT * FROM iocs")]
    wanted=set(observed)
    return [x for x in all_iocs if x["indicator"] in wanted]

class IOC(BaseModel):
    indicator:str=Field(min_length=3,max_length=255)
    kind:str
    source:str=Field(min_length=2,max_length=120)
    confidence:int=Field(ge=0,le=100)
    note:str=Field(default="",max_length=500)

@app.get("/api/iocs")
def iocs():
    with db() as c: return [dict(x) for x in c.execute("SELECT * FROM iocs ORDER BY id DESC")]

@app.post("/api/iocs")
def add_ioc(data:IOC,request:Request):
    indicator=data.indicator.strip()
    if data.kind=="ip":
        indicator=valid_ip(indicator)
        if not indicator: raise HTTPException(400,"عنوان IP غير صالح")
    elif data.kind=="domain":
        if not re.fullmatch(r"(?=.{1,253}$)([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,63}",indicator):
            raise HTTPException(400,"اسم النطاق غير صالح")
        indicator=indicator.lower()
    elif data.kind=="hash":
        if not re.fullmatch(r"(?i)([a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{64})",indicator):
            raise HTTPException(400,"قيمة hash غير صالحة")
        indicator=indicator.lower()
    else: raise HTTPException(400,"نوع المؤشر يجب أن يكون ip أو domain أو hash")
    with db() as c:
        try:
            cur=c.execute("INSERT INTO iocs(indicator,kind,source,confidence,note) VALUES(?,?,?,?,?)",
                (indicator,data.kind,data.source,data.confidence,data.note))
        except Exception: raise HTTPException(409,"المؤشر مسجل مسبقاً")
    audit(actor(request),"ioc_added",indicator)
    return {"ok":True,"id":cur.lastrowid}

class Incident(BaseModel):
    title:str=Field(min_length=3,max_length=160)
    severity:str
    description:str=Field(min_length=3,max_length=4000)

@app.get("/api/incidents")
def incidents():
    with db() as c: return [dict(x) for x in c.execute("SELECT * FROM incidents ORDER BY id DESC")]

@app.post("/api/incidents")
def create_incident(data:Incident,request:Request):
    if data.severity not in ("low","medium","high","critical"): raise HTTPException(400,"خطورة غير صالحة")
    with db() as c:
        cur=c.execute("INSERT INTO incidents(title,severity,description) VALUES(?,?,?)",
                      (data.title,data.severity,data.description))
    audit(actor(request),"incident_created",cur.lastrowid)
    return {"ok":True,"id":cur.lastrowid}

@app.patch("/api/incidents/{incident_id}/close")
def close_incident(incident_id:int,request:Request):
    with db() as c:
        cur=c.execute("UPDATE incidents SET status='closed',updated_at=CURRENT_TIMESTAMP WHERE id=?",(incident_id,))
        if not cur.rowcount: raise HTTPException(404,"الحادث غير موجود")
    audit(actor(request),"incident_closed",incident_id)
    return {"ok":True}

@app.get("/api/findings")
def findings():
    with db() as c: return [dict(x) for x in c.execute("SELECT * FROM findings ORDER BY id DESC LIMIT 300")]

@app.get("/api/audit")
def audit_list():
    with db() as c: return [dict(x) for x in c.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 300")]


# ---- Expert Red Team assessment (authorized, non-destructive) ----
from .expert_engine import assess_asset, tcp_exposure, api_surface_audit, AssessmentError

@app.post("/api/expert/assets/{asset_id}/web-tls")
def expert_web_tls(asset_id:int, request:Request):
    with db() as c: a=c.execute("SELECT * FROM assets WHERE id=?",(asset_id,)).fetchone()
    if not a: raise HTTPException(404,"الأصل غير موجود")
    if not a["approved"]: raise HTTPException(403,"الأصل غير معتمد ضمن النطاق")
    try: result=assess_asset(a["url"])
    except AssessmentError as e: raise HTTPException(400,str(e))
    except Exception as e: raise HTTPException(502,f"Assessment failed: {str(e)[:160]}")
    with db() as c:
        for f in result["web"]["findings"]:
            c.execute("INSERT INTO findings(asset_id,source,severity,title,detail) VALUES(?,?,?,?,?)",
                      (asset_id,"expert_web_tls",f["severity"],f["title"],f["detail"]))
    audit(actor(request),"expert_web_tls",a["url"])
    return result

class PortAuditRequest(BaseModel):
    ports:list[int]=Field(default=[22,80,443,445,3306,3389,5432,6379,8080,8443,9200],max_length=24)

@app.post("/api/expert/assets/{asset_id}/tcp-exposure")
def expert_tcp_exposure(asset_id:int, data:PortAuditRequest, request:Request):
    with db() as c: a=c.execute("SELECT * FROM assets WHERE id=?",(asset_id,)).fetchone()
    if not a: raise HTTPException(404,"الأصل غير موجود")
    if not a["approved"]: raise HTTPException(403,"الأصل غير معتمد ضمن النطاق")
    from urllib.parse import urlparse
    host=urlparse(a["url"]).hostname
    try: result=tcp_exposure(host,data.ports)
    except AssessmentError as e: raise HTTPException(400,str(e))
    opened=[x for x in result["ports"] if x["state"]=="open"]
    with db() as c:
        for item in opened:
            c.execute("INSERT INTO findings(asset_id,source,severity,title,detail) VALUES(?,?,?,?,?)",
                (asset_id,"expert_tcp_exposure","medium",f"TCP port {item['port']} open",
                 f"A TCP handshake succeeded on {host}:{item['port']}. Service identification was not attempted."))
    audit(actor(request),"expert_tcp_exposure",f"{host} ports={data.ports}")
    result["open_count"]=len(opened)
    return result

@app.get("/api/expert/capabilities")
def expert_capabilities():
    return {"profile":"EXPERT + BLACKSHIELD","targets":["approved HTTPS web assets","approved network hosts derived from registered assets"],
      "modules":["web_security_headers","tls_certificate_audit","bounded_tcp_exposure","same_origin_api_metadata_audit","blackshield_firewall_config_audit","periodic_beacon_analytics","local_synthetic_canary_transfer","siem_edr_detection_coverage"],
      "safety":["exact registered asset scope","approval required","single GET; no redirects","fixed bounded TCP handshakes",
                "no exploit payloads","no credential attacks","no stealth or persistence","all actions audited"],
      "not_implemented":["active exploit execution","credential testing","subdomain brute force","authenticated API testing"]}


class APIAuditRequest(BaseModel):
    paths:list[str]=Field(min_length=1,max_length=20)

@app.post("/api/expert/assets/{asset_id}/api-audit")
def expert_api_audit(asset_id:int, data:APIAuditRequest, request:Request):
    with db() as c: a=c.execute("SELECT * FROM assets WHERE id=?",(asset_id,)).fetchone()
    if not a: raise HTTPException(404,"الأصل غير موجود")
    if not a["approved"]: raise HTTPException(403,"الأصل غير معتمد ضمن النطاق")
    try: result=api_surface_audit(a["url"],data.paths)
    except AssessmentError as e: raise HTTPException(400,str(e))
    with db() as c:
        for endpoint in result["results"]:
            for finding in endpoint.get("findings",[]):
                c.execute("INSERT INTO findings(asset_id,source,severity,title,detail) VALUES(?,?,?,?,?)",
                    (asset_id,"expert_api_audit",finding["severity"],finding["title"],
                     f"{endpoint['path']}: {finding['detail']}"))
    audit(actor(request),"expert_api_audit",f"{a['url']} paths={len(data.paths)}")
    return result


@app.get("/api/reports/export", response_class=HTMLResponse)
def export_report(request: Request, lang: str = "both"):
    """Generate a self-contained printable report from stored platform records."""
    import html
    if lang not in ("ar", "en", "both"):
        raise HTTPException(400, "lang must be ar, en, or both")
    with db() as c:
        assets_rows = [dict(x) for x in c.execute("SELECT * FROM assets ORDER BY id DESC")]
        finding_rows = [dict(x) for x in c.execute("SELECT * FROM findings ORDER BY id DESC LIMIT 500")]
        incident_rows = [dict(x) for x in c.execute("SELECT * FROM incidents ORDER BY id DESC LIMIT 200")]
    e = html.escape
    title = "ALPHA SENTINEL X — Security Assessment Report"
    ar = "تقرير التقييم الأمني"
    def label(a, b):
        return a if lang == "ar" else b if lang == "en" else f"{a} / {b}"
    rows_assets = "".join(f"<tr><td>{e(x['name'])}</td><td dir='ltr'>{e(x['url'])}</td><td>{'Approved' if x['approved'] else 'Not approved'}</td><td>{e(x['authorization_ref'])}</td></tr>" for x in assets_rows)
    rows_findings = "".join(f"<tr><td>{e(x['created_at'])}</td><td>{e(x['severity'])}</td><td>{e(x['source'])}</td><td>{e(x['title'])}</td><td>{e(x['detail'])}</td></tr>" for x in finding_rows)
    rows_incidents = "".join(f"<tr><td>{e(x['created_at'])}</td><td>{e(x['severity'])}</td><td>{e(x['status'])}</td><td>{e(x['title'])}</td><td>{e(x['description'])}</td></tr>" for x in incident_rows)
    doc = f"""<!doctype html><html lang='{ 'ar' if lang == 'ar' else 'en' }'><meta charset='utf-8'><meta name='viewport' content='width=device-width'><title>{e(title)}</title><style>body{{font:14px system-ui,sans-serif;margin:32px;color:#172033}}h1,h2{{color:#172b4d}}table{{width:100%;border-collapse:collapse;margin:14px 0 28px}}th,td{{border:1px solid #ccd3df;padding:8px;text-align:start;vertical-align:top;overflow-wrap:anywhere}}th{{background:#eef2f8}}.meta{{color:#53627a}}@media print{{button{{display:none}}body{{margin:12mm}}}}</style><body dir='{ 'rtl' if lang == 'ar' else 'ltr' }'><button onclick='window.print()'>Print / PDF</button><h1>{e(title)}</h1><p class='meta'>{e(ar)} • Generated UTC: {__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()} • v4.0.0</p><h2>{e(label('الأصول والنطاق','Assets & Scope'))}</h2><table><thead><tr><th>Name</th><th>URL</th><th>Scope</th><th>Authorization ref</th></tr></thead><tbody>{rows_assets or '<tr><td colspan=4>No assets</td></tr>'}</tbody></table><h2>{e(label('النتائج الأمنية','Security Findings'))}</h2><table><thead><tr><th>Date</th><th>Severity</th><th>Source</th><th>Finding</th><th>Details</th></tr></thead><tbody>{rows_findings or '<tr><td colspan=5>No findings</td></tr>'}</tbody></table><h2>{e(label('الحوادث','Incidents'))}</h2><table><thead><tr><th>Date</th><th>Severity</th><th>Status</th><th>Title</th><th>Description</th></tr></thead><tbody>{rows_incidents or '<tr><td colspan=5>No incidents</td></tr>'}</tbody></table><p class='meta'>Assessment data is evidence for review, not proof of exploitability. Validate findings in the authorized environment.</p></body></html>"""
    audit(actor(request), "report_export", f"lang={lang}; findings={len(finding_rows)}")
    return HTMLResponse(doc, headers={"Content-Disposition": "attachment; filename=alpha-sentinel-report.html"})

# ---- BLACKSHIELD: defensive validation and detection engineering ----
from .blackshield import (
    BlackshieldError, audit_firewall_config, analyze_beacon_csv,
    run_local_canary_test, compare_detection_coverage,
)

@app.post("/api/blackshield/firewall-audit")
async def blackshield_firewall_audit(request: Request, file: UploadFile = File(...)):
    name = (file.filename or "firewall.txt").lower()
    if not name.endswith((".txt", ".conf", ".cfg", ".rules", ".export")):
        raise HTTPException(400, "ارفع ملف إعدادات نصياً بصيغة مدعومة")
    raw = await file.read(2 * 1024 * 1024 + 1)
    if len(raw) > 2 * 1024 * 1024:
        raise HTTPException(413, "الحد الأقصى لملف الجدار الناري 2 MB")
    try:
        result = audit_firewall_config(raw, file.filename or "firewall.txt")
    except BlackshieldError as exc:
        raise HTTPException(400, str(exc))
    with db() as c:
        for finding in result["findings"]:
            c.execute("INSERT INTO findings(source,severity,title,detail) VALUES(?,?,?,?)",
                      ("blackshield_firewall", finding["severity"], finding["title"],
                       finding["detail"] + (" Evidence: " + finding["evidence"] if finding.get("evidence") else "")))
    audit(actor(request), "blackshield_firewall_audit", file.filename or "firewall.txt")
    return result

@app.post("/api/blackshield/beacon-audit")
async def blackshield_beacon_audit(request: Request, file: UploadFile = File(...)):
    if not (file.filename or "").lower().endswith(".csv"):
        raise HTTPException(400, "ارفع سجل حركة مرور CSV")
    raw = await file.read(10 * 1024 * 1024 + 1)
    if len(raw) > 10 * 1024 * 1024:
        raise HTTPException(413, "الحد الأقصى 10 MB")
    try:
        result = analyze_beacon_csv(raw)
    except BlackshieldError as exc:
        raise HTTPException(400, str(exc))
    for candidate in result["beacon_candidates"]:
        with db() as c:
            c.execute("INSERT INTO findings(source,severity,title,detail) VALUES(?,?,?,?)",
                      ("blackshield_beacon", "medium", "Possible periodic beacon pattern",
                       f"{candidate['destination']}:{candidate.get('port') or 'unknown'}; "
                       f"connections={candidate['connections']}; interval_cv={candidate['interval_cv']}"))
    audit(actor(request), "blackshield_beacon_audit", f"rows={result['rows_analyzed']}")
    return result

@app.post("/api/blackshield/canary-test")
def blackshield_canary_test(request: Request):
    try:
        result = run_local_canary_test()
    except BlackshieldError as exc:
        raise HTTPException(400, str(exc))
    audit(actor(request), "blackshield_local_canary", f"test_id={result['test_id']}; integrity={result['integrity_match']}")
    return result

@app.post("/api/blackshield/detection-coverage")
async def blackshield_detection_coverage(request: Request, file: UploadFile = File(...), expected_event_ids: str = Form(...)):
    if not (file.filename or "").lower().endswith(".csv"):
        raise HTTPException(400, "ارفع تصدير SIEM/EDR بصيغة CSV")
    raw = await file.read(10 * 1024 * 1024 + 1)
    if len(raw) > 10 * 1024 * 1024:
        raise HTTPException(413, "الحد الأقصى 10 MB")
    try:
        ids = [x.strip() for x in expected_event_ids.split(",") if x.strip()]
        result = compare_detection_coverage(raw, ids)
    except BlackshieldError as exc:
        raise HTTPException(400, str(exc))
    audit(actor(request), "blackshield_detection_coverage", f"coverage={result['coverage_percent']}%; expected={result['expected_events']}")
    return result

@app.get("/api/blackshield/capabilities")
def blackshield_capabilities():
    return {
        "engine": "BLACKSHIELD",
        "modules": ["firewall_config_audit", "periodic_beacon_analytics", "local_synthetic_canary_transfer", "siem_edr_detection_coverage"],
        "scope": "defensive configuration review, supplied telemetry analysis, and local synthetic-file workflow",
        "limitations": ["No firewall bypass", "No covert network transfer", "No credential collection", "No persistence", "No disabling or evading endpoint protection"],
        "canary_mode": "local source-to-sink copy only; no network transfer"
    }
