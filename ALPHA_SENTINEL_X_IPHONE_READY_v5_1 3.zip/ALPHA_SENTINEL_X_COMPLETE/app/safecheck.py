import socket, ipaddress, ssl, http.client
from urllib.parse import urlparse, quote

HEADERS = [
 ("strict-transport-security","HSTS","medium","فعّل HSTS بعد التأكد من إعداد HTTPS لجميع النطاقات الفرعية المعنية."),
 ("content-security-policy","CSP","medium","أضف سياسة CSP مناسبة لتطبيقك."),
 ("x-content-type-options","X-Content-Type-Options","low","اضبط nosniff."),
 ("referrer-policy","Referrer-Policy","low","اضبط سياسة إحالة تقلل تسريب المسارات."),
 ("permissions-policy","Permissions-Policy","low","قيّد واجهات المتصفح غير المطلوبة.")
]

def check_https_baseline(url):
    p=urlparse(url)
    if p.scheme!="https" or not p.hostname or p.username or p.password or p.port not in (None,443):
        raise ValueError("يقبل HTTPS على المنفذ 443 فقط، دون بيانات اعتماد داخل الرابط")
    host=p.hostname.lower()
    if host=="localhost" or host.endswith(".localhost"):
        raise ValueError("localhost غير مقبول ضمن فاحص الأصول العامة")
    try:
        addresses={x[4][0] for x in socket.getaddrinfo(host,p.port or 443,type=socket.SOCK_STREAM)}
    except Exception:
        raise ValueError("تعذر حل اسم المضيف")
    allow_private = __import__("os").getenv("ALLOW_PRIVATE_TARGETS", "false").lower() == "true"
    for addr in addresses:
        parsed_addr = ipaddress.ip_address(addr)
        if not parsed_addr.is_global and not allow_private:
            raise ValueError("المضيف يحل إلى عنوان غير عام؛ فعّل ALLOW_PRIVATE_TARGETS فقط لبيئة داخلية مصرح بها")
        if parsed_addr.is_loopback or parsed_addr.is_link_local or parsed_addr.is_multicast or parsed_addr.is_unspecified:
            raise ValueError("عناوين loopback وlink-local وmulticast محظورة")
    # One metadata-only GET, pinned to the already validated DNS answer.
    pinned_ip = sorted(addresses)[0]
    raw = socket.create_connection((pinned_ip, p.port or 443), timeout=3)
    try:
        with ssl.create_default_context().wrap_socket(raw, server_hostname=host) as tls:
            path = quote(p.path or "/", safe="/%:@!$&'()*+,;=-._~")
            if p.query:
                path += "?" + quote(p.query, safe="=&;%:@!$'()*+,/?-._~")
            host_header = f"[{host}]" if ":" in host else host
            request = (f"GET {path} HTTP/1.1\r\nHost: {host_header}\r\n"
                       "User-Agent: ALPHA-SENTINEL-X/4.0 authorized-baseline\r\n"
                       "Connection: close\r\n\r\n")
            tls.sendall(request.encode("ascii"))
            response = http.client.HTTPResponse(tls)
            response.begin()
            status = response.status
            h = {k.lower(): v for k, v in response.getheaders()}
            response.close()
    finally:
        try: raw.close()
        except OSError: pass
    findings=[]
    for key,label,severity,advice in HEADERS:
        if key not in h:
            findings.append({"severity":severity,"title":f"ترويسة مفقودة: {label}","detail":advice})
    if 300<=status<400:
        findings.append({"severity":"info","title":"إعادة توجيه HTTP","detail":"تم إيقاف الفحص عند الاستجابة التحويلية؛ افحص الوجهة بعد إضافتها واعتمادها في النطاق."})
    return {"status_code":status,"final_url":url,
            "redirect_not_followed":300<=status<400,
            "findings":findings,"server_header_present":"server" in h}
